$(document).ready(function() {
	
	CKEDITOR.replace( 'registration', {
		filebrowserBrowseUrl: '/ckfinder/ckfinder.html',
	    filebrowserImageBrowseUrl: '/ckfinder/ckfinder.html?Type=Images',
	    filebrowserFlashBrowseUrl: '/ckfinder/ckfinder.html?Type=Flash',
	    filebrowserUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
	    filebrowserImageUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
	    filebrowserFlashUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
	});
	
	const uri = K.getWebSocketURL();
	K.bind(uri);
	K.addEventListener(function(e) {
		switch (e.event) {
		case 'open': 
			K.control.load('product');
			K.control.load('registration', function() {
				K.control.requestStart('registration');
			});
			break;
		} // switch
	});
	$(window).bind('beforeunload', function() {
		console.log("beforeunload");
		K.removeEchoEvent();
		K.uninit();
		return 'are you sure you want to leave?';
	});
	
	// thumbnail
	$('#product-thumbnail').bind('change', handleFileSelect);
});



function isNumber(evt) {
	console.log(evt);
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[0-9]|\./;
	if (!regex.test(key)) {
		alert("Please input only numeric");
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}

function naviProduct() {
	$('#product-menu').attr('class', 'active');
	$('#registrtation-menu').attr('class', '');
	K.control.requestStart('product');
}

function naviRegistration() {
	$('#registrtation-menu').attr('class', 'active');
	$('#product-menu').attr('class', '');
	K.control.requestStart('registration');
}


function confirm() {
	
	var file = document.getElementById('product-thumbnail').files[0];
	var reader = new FileReader();
	var rawData = new ArrayBuffer();
	
	var name = document.getElementById('product-name').value;
	var price0 = document.getElementById('product-price0').value;
	var price1 = document.getElementById('product-price1').value;
	var description = CKEDITOR.instances.registration.document.$.body.innerHTML;

	reader.loadend = function() {

	}
	reader.onload = function(e) {
		rawData = e.target.result;
		//var object = {"jsonrpc": "2.0", "method": "system::upload", "data": rawData};
		//ws.send(object);
		//console.log("the File has been transferred.");
		
//		K.upload("ddd.png", rawData);
		K.addProduct(rawData, name, price0, price1, description);
		
		productFormReset();
		
//		K.control.requestStart('product');
		
		naviProduct();
	}

	
	if(msieversion() == true) {
		reader.readAsArrayBuffer(file);
	} else {
		reader.readAsBinaryString(file);
	}
	
}


function msieversion() {

	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE ");

	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If
																		// Internet
																		// Explorer,
																		// return
																		// version
																		// number
//		alert(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
		return true;
	else
		// If another browser, return 0
//		alert('otherbrowser');

	return false;
}

function cancel() {
	productFormReset();
}


function productFormReset(){
	
	//product name
//	document.getElementById("product-form").reset();
	document.getElementById('product-name').value = "";
	
	//product thumbnail-preview
	document.getElementById('product-thumbnail-preview').src = "";
	
	//product thumbnail
	document.getElementById('product-thumbnail').value = "";
	
	//product price
	document.getElementById('product-price0').value = "";
	document.getElementById('product-price1').value = "";
	
	//editor - product description
	for ( instance in CKEDITOR.instances ) {
		CKEDITOR.instances[instance].updateElement();
	    CKEDITOR.instances[instance].setData('');
	}
}


function getList() {
	
	var div = document.getElementById('product-list');
	while (div.firstChild) {
		div.removeChild(div.firstChild);
	}
	K.listProduct();
}


function handleFileSelect(evt) {
	var files = evt.target.files; // FileList object
	console.log(files);

	// Loop through the FileList and render image files as thumbnails.
	for (var i = 0, f; f = files[i]; i++) {

		// Only process image files.
		if (!f.type.match('image.*')) {
			continue;
		}

		var reader = new FileReader();

		// Closure to capture the file information.
		reader.onload = (function(theFile) {
			return function(e) {
				// Render thumbnail.
				var image = document.getElementById('product-thumbnail-preview');
				image.setAttribute('src', e.target.result);
			};
		})(f);

		// Read in the image file as a data URL.
		reader.readAsDataURL(f);
	}
}








