
var APP_STATUS = {
	NONE : 0,
	INITIALIZED : 1,
	STARTED : 2,
	PAUSED : 3,
	DESTROYED : 4,
};

// $xxx are frame work functions. You do not call them. 
var App = Class.extend({
	status:null,
	id : function() {
		console.log("You should override this method");
	},
	$init : function() {
		console.log("App.init");
		this.setStatus(APP_STATUS.INITIALIZED);
	},
	$start : function() {
		console.log("App.start");
		this.setStatus(APP_STATUS.STARTED);
	},
	$pause : function() {
		console.log("App.pause");
		this.setStatus(APP_STATUS.PAUSED);
	},
	$destroy : function() {
		console.log("App.destroy");
		this.setStatus(APP_STATUS.DESTROYED);
	},
	$eventListener : function(e0) {
		console.log("App.$eventListener");
	},
	setStatus : function(status) {
		console.log("App.setStatus:" + status);
		var previous = this.status;
		this.status = status;
		var current = 	this.status;
		console.log("status " + previous +  " to " + current);
	},
	getStatus : function() {
		console.log("getStatus : " + this.status);
		return this.status;
	},
});

var ctl_self = null;
var _Control = Class.extend({
	apps:null,
	currentApp:null,
	context : null,
	init : function() {
		console.log("_Control.init");
		this.currentApp = null;
		this.apps = new Object();
		ctl_self = this;
		K.addEventListener(this.eventListener);
	},
	uninit : function() {
		console.log("_Control.uninit");
	},
	load : function(app, fn /* complete callback */) {
		console.log("_Control.load:" + app);
		
		var head= document.getElementsByTagName('head')[0];
		
		// load css
		var cssPath ="apps/" +  app + "/" + app + ".css";
		var css = document.createElement('link');
		css.type = 'text/css';
		css.rel = 'stylesheet';
		css.href = cssPath;
		css.media = 'screen';
		head.appendChild(css);

		// load script
		var script = document.createElement("script");
		var path = "apps/"+ app + "/" + app + ".js";
		console.log("path: " + path);
		script.setAttribute("src",  path);
		script.onload = function() {
			var $app = new (eval(app))();
			if($app == null || $app == undefined) {
				console.log("No such application : <" + app + ">");
				return;
			}
			var id = $app.id();
			console.log("application id : " + id);
			ctl_self.apps[id] = $app;
			$app.$init();
			if(fn) {
				fn.call($app);
			}
		};
		head.appendChild(script);
	},
	requestStart : function(id) { // app id
		console.log("requestStart : <" + id + ">, current app: <" + ctl_self.currentApp +  ">");
		if(ctl_self.currentApp != null || ctl_self.currentApp != undefined) {
			if(ctl_self.currentApp.getStatus() == APP_STATUS.STARTED) {
				ctl_self.currentApp.$pause();	
			}	
		}
		
		var $app = ctl_self.apps[id];

		if($app) {
			ctl_self.currentApp = $app;
			ctl_self.currentApp.$start();
		}
		else {
			console.log("No such an app exception : <" + id + ">");
		}
	},
	getAppIDs : function() {
        var keys = new Array();   
        for(var prop in this.map){   
            keys.push(prop);
        }   
        return keys;
	},
	eventListener : function(e) {
		if(ctl_self.currentApp != undefined && ctl_self.currentApp != null && ctl_self.currentApp.$eventListener) {
			ctl_self.currentApp.$eventListener(e);
		}
		else {
			console.log("app doesn't seem normal : " + ctl_self.currentApp);
		}
		return;
		
		switch(e.event) {
		case 'open':  {// if you call k.bind and it success, this routine will be called.
		 //K.subscribeEvent('dmsEvent'); // It looks better way to subscribe an event that you want to monitor.
		//	K.addChannelEvent();
			//K.requestChannels();
		
			// add App
			
			break;
		}
		case 'close': {
			break;
		}
		case 'channelFound': {
			break;
		}
		case 'channelChanged': {
			//TODO:
			break;
		}
		case 'message': {
			console.log("message: " + e.msg + ", who: " + e.who);
		}
		default:
			alert("unknown: " + e);
			break;
		}
	}
});


var _K = Class.extend({
	websocket: null,
	eventListeners:null,
	control:null,
	init: function() {
		console.log("K.init");
		eventListeners = new Array();
		fireEvent =  function(e0) {
			for(var i = 0; i < eventListeners.length; i++) {
				eventListeners[i](e0);
			}
		};

		messageReceived = function(e0) {
			try {
				msg = JSON.parse(e0.data);
				fireEvent(msg);
			} catch(e) {
				console.log(e + ":" + e0.data);
			}
		};
	},
	addEventListener: function(fn) {
		console.log("addEventListeners");
		eventListeners[eventListeners.length] = fn;
	},
	bind: function(uri) {
		console.log("bind");
		this.websocket = new WebSocket(uri);
		this.websocket.onopen = function(e0) {
			var event = {};
			event.event = "open";
			fireEvent(event);
		};
		this.websocket.onclose = function(e0) {
			var event = {};
			event.event = "close";
			fireEvent(event);
		};
		this.websocket.onmessage = function(e0) {
			messageReceived(e0);
		};
		this.websocket.onerror = function(e0) {
			var event = {};
			event.event = "error";
			fireEvent(event);
		};
	},
	getBindListByHash: function(hash) {
		console.log("getBindListByHash : " + hash);
		var object = {"jsonrpc": "2.0", "method": "product::list_bound_by_hash", "hash": hash, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	bindProductByHash: function(hash, major, minor, status) {
		console.log("bindProductByHash");
		var object = {"jsonrpc": "2.0", "method": "product::bind_by_hash", "hash": hash, "major": major, "minor": minor, "status": status, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
		console.log(object);
	},
	getBindList: function(name) {
		console.log("getBindList : " + name);
		var object = {"jsonrpc": "2.0", "method": "product::list_bound", "name": name, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	bindProduct: function(name, major, minor, status) {
		console.log("bindProduct");
		var object = {"jsonrpc": "2.0", "method": "product::bind", "name": name, "major": major, "minor": minor, "status": status, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
		console.log(object);
	},
	listProduct: function() {
		console.log("product::list");
		var object = {"jsonrpc": "2.0", "method": "product::list", "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	addProduct: function(thumbnail, name, price0, price1, description) {
		console.log("product::add:");
		var object = {"jsonrpc": "2.0", "method": "product::add", "thumbnail": $.base64.encode(thumbnail), "name": name, "price0": price0, "price1": price1, "description": description, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	upload: function(name, data) {
		//console.log("upload: " + data);
		var object = {"jsonrpc": "2.0", "method": "system::upload", "name": name ,"data": $.base64.encode(data), "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	subscribeEvent: function(name) {
		console.log("subscribeEvent: " + name);
		var object = {"jsonrpc": "2.0", "method": name, "params": 1, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	unsubscribeEvent: function(name) {
		console.log("unsubscribeEvent: " + name);
		var object = {"jsonrpc": "2.0", "method": name, "params": 1, "id": 10}; // TODO: params isn't required.
		this.websocket.send(JSON.stringify(object));
	},
	addDmsEvent: function() { //@deprecataed, subscribeEvent is preferred instead
		console.log("addDmseventListeners");
		var object = {"jsonrpc": "2.0", "method": "dmc::addEventListener", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	removeDmsEvent: function() {//@deprecataed, subscribeEvent is preferred
		console.log("removeEvent");
		var object = {"jsonrpc": "2.0", "method": "dmc::removeEventListener", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	addChannelEvent: function() { //@deprecataed, subscribeEvent is preferred instead
		console.log("addChannelEventListeners");
		var object = {"jsonrpc": "2.0", "method": "tv::addEventListener", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	removeChannelEvent: function() {//@deprecataed, subscribeEvent is preferred
		console.log("removeEvent");
		var object = {"jsonrpc": "2.0", "method": "tv::removeEventListener", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	subscribeServer : function (uuid) {
		console.log("subscribeServer : " + uuid);
		var object = {"jsonrpc": "2.0", "method": "dmc::subscribeServer", "uuid": uuid, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	browse: function (uuid, objectId, startIndex, count) {
		console.log("browse");
		var object = {"jsonrpc": "2.0", "method": "dmc::browse", "id": 10, "uuid":uuid, "objectId": objectId, "startIndex": startIndex, "count" : count};
		this.websocket.send(JSON.stringify(object));
	},
	getMediaInfo: function (uuid, objectId) {
		console.log("getMediaInfo");
		var object = {"jsonrpc": "2.0", "method": "dmc::getMediaInfo", "id": 10, "uuid":uuid, "objectId": objectId};
		this.websocket.send(JSON.stringify(object));
	},
	addEchoEvent : function() {
		var object = {"jsonrpc": "2.0", "method": "echo::join", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	removeEchoEvent : function() {
		var object = {"jsonrpc": "2.0", "method": "echo::leave", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	log : function(msg){
		var object = {"jsonrpc": "2.0", "method": "echo::broadcastMessage", "msg":msg , "who":"logger", "id": 1};
		this.websocket.send(JSON.stringify(object));
	},
	scan : function(){
		var object = {"jsonrpc": "2.0", "method": "wifi::scan", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	scanResults : function(){
		var object = {"jsonrpc": "2.0", "method": "wifi::scanResults", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	bitrateMeasureStart : function(alias) {
		var object = {"jsonrpc": "2.0", "method": "diagnostic::bitrateMeasureStart", "alias": alias, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	bitrateMeasureStop : function() {
		var object = {"jsonrpc": "2.0", "method": "diagnostic::bitrateMeasureStop", "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	iperf : function(ip) {
		var object = {"jsonrpc": "2.0", "method": "diagnostic::iperf", "ip": ip, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	iflist : function() {
		var object = {"jsonrpc": "2.0", "method": "system::iflist", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	getIp : function(alias) {
		var object = {"jsonrpc": "2.0", "method": "system::getIp", "alias": alias, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	memInfo : function() {
		var object = {"jsonrpc": "2.0", "method": "system::memInfo", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	networkTraffic : function(alias) {
		var object = {"jsonrpc": "2.0", "method": "system::networkTraffic", "alias": alias, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	webcamJoin : function() {
		var object = {"jsonrpc": "2.0", "method": "webcam::join", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	webcamLeave : function() {
		var object = {"jsonrpc": "2.0", "method": "webcam::leave", "params": 1, "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	softwareupdate : function(){
		var object = {"jsonrpc": "2.0", "method": "system::softwareupdate", "id": 1};
		this.websocket.send(JSON.stringify(object));
	},
	factoryReset : function(){
		var object = {"jsonrpc": "2.0", "method": "system::factoryReset", "id": 1};
		this.websocket.send(JSON.stringify(object));
	},
	volume : function(up) { // TODO
		if(up == true) {
		}
		else {
		}
	},
	channel : function(up) { // TODO
		if(up == true) {
			
		}
		else  {
			
		}
	},
	requestChannels : function() {
		console.log("requestChannels");
		var object = {"jsonrpc": "2.0", "method": "tv::requestChannels", "id": 10};
		this.websocket.send(JSON.stringify(object));
	},
	dca : function(no) { // TODO : Direct Channel Acccess
		
	},
	uninit: function() {
		this.removeDmsEvent(); //TODO: It requires this. I need to get clear concept for this. dig into it.
		
		this.websocket.onclose = function(){};  // make it empty.
		this.websocket.close();
		
	},
	getWebSocketURL : function() {
		var pcol;
		var u = document.URL;
		if (u.substring(0, 5) == "https") {
			pcol = "wss://";
			u = u.substr(8);
		} else {
			pcol = "ws://";
			if (u.substring(0, 4) == "http")
				u = u.substr(7);
		}
		u = u.split('/');
		return pcol + u[0];
	},
	createControl: function() {
		this.control = window.K.control = new _Control();
	},
	arrayBufferDataUri : function(raw) {
	    var base64 = '';
	    var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	    var bytes = new Uint8Array(raw);
	    var byteLength = bytes.byteLength;
	    var byteRemainder = byteLength % 3;
	    var mainLength = byteLength - byteRemainder;
	    var a, b, c, d;
	    var chunk;
	    // Main loop deals with bytes in chunks of 3
	    for (var i = 0; i < mainLength; i = i + 3) {
	        // Combine the three bytes into a single integer
	        chunk = (bytes[i] << 16) | (bytes[i + 1] << 8 ) | bytes[i + 2];
	        // Use bitmasks to extract 6-bit segments from the triplet
	        a = (chunk & 16515072) >> 18; // 16515072 = (2^6 - 1) << 18
	        b = (chunk & 258048) >> 12;   // 258048   = (2^6 - 1) << 12
	        c = (chunk & 4032) >> 6;      // 4032     = (2^6 - 1) << 6
	        d = chunk & 63;               // 63       = 2^6 - 1
	        // Convert the raw binary segments to the appropriate ASCII encoding
	        base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d]
	    }
	    // Deal with the remaining bytes and padding
	    if (byteRemainder == 1) {
	        chunk = bytes[mainLength];
	        a = (chunk & 252) >> 2; // 252 = (2^6 - 1) << 2
	        // Set the 4 least significant bits to zero
	        b = (chunk & 3) << 4;   // 3   = 2^2 - 1
	        base64 += encodings[a] + encodings[b] + '==';
	    }
	    else if (byteRemainder == 2) {
	        chunk = (bytes[mainLength] << 8 ) | bytes[mainLength + 1];
	        a = (chunk & 16128) >> 8; // 16128 = (2^6 - 1) << 8
	        b = (chunk & 1008) >> 4;  // 1008  = (2^6 - 1) << 4
	        // Set the 2 least significant bits to zero
	        c = (chunk & 15) << 2;    // 15    = 2^4 - 1
	        base64 += encodings[a] + encodings[b] + encodings[c] + '=';
	    }
	    return "data:image/jpeg;base64," + base64;
	},
});



(function() {
	var K = window.K = new _K();
	K.createControl();
})();


